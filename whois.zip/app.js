'use strict';
const whois = require('whois')

exports.handler = (event, context, callback) => {

    whois.lookup(event.address, (err, data) => {
        if(err) {
            callback(null, "Failed to get data on address")
        }
        callback(null, processData(data));
    })
}


const processData = (data) => {

    let arr = data.split("\n")

    let processed = ""
    for(let i = 0; i < arr.length; i++) {
        const str = arr[i];
        console.log(str)
        if(str.indexOf("Registrar") > -1) {
            console.log('clearing registrar')
            continue
        }
        if(str.indexOf("Domain Status") > -1) {
            console.log("clearing domain status")
            continue
        }
        if(str.indexOf("DNSSEC") > -1) {
            console.log("exiting loop")
            break;
        }
        if(str.indexOf("% This is the RIPE Database query service.") > -1) {
            processed = "ERROR"
            break;
        }

        processed += str + "\n"
    }
    console.log("processed:")
    console.log(processed)

    return processed;
}